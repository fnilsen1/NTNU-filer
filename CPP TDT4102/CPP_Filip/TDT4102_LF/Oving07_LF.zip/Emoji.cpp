#include "Emoji.h"

// Et gult, tomt ansikt.
Face::Face(Point c, int r) : centre{c}, radius{r} {}

void Face::draw(AnimationWindow& win)
{
	win.draw_circle(centre, radius, Color::yellow);
}

// Et ansikt med to øyne.
EmptyFace::EmptyFace(Point c, int r)
	: Face{c, r},
	  leftEyePosition{c.x - 10, c.y - 5},
	  rightEyePosition{c.x + 10, c.y - 5},
	  eyeRadius{10} {}

void EmptyFace::draw(AnimationWindow& win)
{
	Face::draw(win);
	win.draw_circle(leftEyePosition, eyeRadius, Color::green);
	win.draw_circle(rightEyePosition, eyeRadius, Color::green);
}

// Et klassisk smilefjes, som arver fra EmptyFace
SmilingFace::SmilingFace(Point centre, int radius)
	: EmptyFace{centre, radius} {
		mouthPosition = {centre.x, centre.y + 10};
		mouthWidth = 30;
		mouthHeight = 25;
		mouthStartAngle = 180;
		mouthEndAngle = 360;
	}

void SmilingFace::draw(AnimationWindow& win)
{
	EmptyFace::draw(win);
	
	win.draw_arc(mouthPosition, mouthWidth, mouthHeight, mouthStartAngle, mouthEndAngle, Color::black);
}

// Et overasket ansikt, som arver fra SmilingFace. mouth tegnes helt rundt,
// og er forskjøvet litt fra midten.
SurprisedFace::SurprisedFace(Point c, int r) : SmilingFace{c, r}
{
	mouthHeight = 17;
	mouthPosition = {mouthPosition.x, mouthPosition.y + 15};
	mouthStartAngle = 0;
}

// Et trist ansikt, som arver fra EmptyFace.
SadFace::SadFace(Point c, int r)
	: EmptyFace{c, r} {}

void SadFace::draw(AnimationWindow& win)
{
	EmptyFace::draw(win);
	win.draw_arc({centre.x, centre.y + 30}, 30, 25, 0, 180, Color::blue);
}

// Sint ansikt med firkantmunn og synlige tenner.
AngryFace::AngryFace(Point c, int r)
	: EmptyFace{c, r} {}

void AngryFace::draw(AnimationWindow& win)
{
	EmptyFace::draw(win);

	const Point mouthPosition = Point{centre.x - 60 / 2, centre.y + 10};
	win.draw_rectangle(mouthPosition, 60, 20, Color::white, Color::black);
	for (int i = -25; i <= 25; i += 5) {
		win.draw_line(Point{centre.x - i, mouthPosition.y},
				      Point{centre.x - i, mouthPosition.y + 19},
					  Color::black);
	}
	
	win.draw_line(Point{centre.x - 20, centre.y - 20}, Point{centre.x - 5, centre.y - 13}, Color::black);
	win.draw_line(Point{centre.x + 20, centre.y - 20}, Point{centre.x + 5, centre.y - 13}, Color::black);
}

// Et ansikt med et nøytralt utseende - rettlinjet munn.
NeutralFace::NeutralFace(Point c, int r)
	: EmptyFace{c, r} {}

void NeutralFace::draw(AnimationWindow& win)
{
	EmptyFace::draw(win);
	win.draw_line(Point{centre.x - 30, centre.y + 10}, Point{centre.x + 30, centre.y + 10}, Color::black);
}

// Et ansikt som ligner på SmilingFace med et blunkende høyreøye (160 deg Arc).
WinkFace::WinkFace(Point c, int r)
	: Face{c, r} {}

void WinkFace::draw(AnimationWindow& win)
{
	Face::draw(win);

	win.draw_circle(Point{centre.x - 10, centre.y - 5}, 10, Color::green);
	win.draw_arc(Point{centre.x + 15, centre.y}, 15, 17, 0, 170, Color::black);
	win.draw_arc(Point{centre.x, centre.y + 10}, 30, 25, 180, 360, Color::black);
}
