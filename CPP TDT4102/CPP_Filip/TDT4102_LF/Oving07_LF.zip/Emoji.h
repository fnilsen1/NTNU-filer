#pragma once
#include "std_lib_facilities.h"
#include "AnimationWindow.h"

// Abstrakt klasse. Arvende konkrete klasser må implementere funksjonen draw()
// som tegner former i vinduet de skal bli vist i.
class Emoji
{
public:
	virtual void draw(AnimationWindow&) = 0;
	virtual ~Emoji(){}; //Destruktør
};

// Et gult, tomt ansikt.
// En abstrakt klasse.
class Face : public Emoji
{
public:
	Face(Point c, int r);
	void draw(AnimationWindow& win) override = 0;

protected:
	Point centre {0, 0};
	int radius = 0;
};

// Et ansikt med to øyne.
class EmptyFace : public Face
{
public:
	EmptyFace(Point c, int r);
	void draw(AnimationWindow& win) override;

private:
	Point leftEyePosition {0, 0};
	Point rightEyePosition {0, 0};
	int eyeRadius = 0;
};

// Et klassisk smilefjes, som arver fra EmptyFace.
class SmilingFace : public EmptyFace
{
public:
	SmilingFace(Point c, int r);
	void draw(AnimationWindow& win) override;
protected:
	Point mouthPosition {0, 0};
	int mouthWidth = 0;
	int mouthHeight = 0;
	int mouthStartAngle = 0;
	int mouthEndAngle = 0;
};

// Et overasket ansikt, som arver fra SmilingFace. Munnen tegnes helt rundt,
// og er forskjøvet litt fra midten.
// NB: dette er ment som et eksempel på dårlig kode!
class SurprisedFace : public SmilingFace
{
public:
	SurprisedFace(Point c, int r);
	// Det kan virke fornuftig å gjenbruke mouth fra SmilingFace-klassen,
	// som i dette eksempelet, da man slipper å definere draw()
	// eller deklarere mouth på nytt. Men det å arve fra en konkret klasse
	// kun for å unngå duplisering av kode er sjelden en god idé. I
	// dette tilfellet er problemet at det skaper en avhengighet mellom
	// SurprisedFace og SmilingFace. Hvis f.eks. SmilingFace plutselig
	// også får "smilende øyne" eller munnen endres litt, så vil dette
	// også endre på SurprisedFace-klassen. Man kan også prøve å tenke
	// på det intuitivt og si: "SurprisedFace er en type SmilingFace",
	// eller "SurprisedFace er en spesialisering av SmilingFace", og
	// konkludere med at dette ikke gir mye mening her.
};

// Et trist ansikt, som arver fra EmptyFace.
class SadFace : public EmptyFace
{
public:
	SadFace(Point c, int r);
	void draw(AnimationWindow& win) override;
	// Her arver vi fra EmptyFace. Det betyr at om vi endrer på den triste
	// munnen, så vil ikke dette påvirke andre klasser. Merk at dersom vi
	// hadde ønsket egne "triste øyne", så kunne det vært lurt å arve
	// direkte fra Face for å unngå avhengigheten til EmptyFace sine øyne.
	// Her er vi riktignok fornøyde med at SadFace har de samme øynene
	// som EmptyFace, og derfor er dette en fullgod løsning.
};

// Sint ansikt med firkantmunn og synlige tenner.
class AngryFace : public EmptyFace
{
public:
	AngryFace(Point c, int r);
	void draw(AnimationWindow& win) override;
};

// Et ansikt med et nøytralt utseende - rettlinjet munn.
class NeutralFace : public EmptyFace
{
public:
	NeutralFace(Point c, int r);
	void draw(AnimationWindow& win) override;
};

// Et ansikt som ligner på SmilingFace med et blunkende høyreøye (160 deg Arc).
class WinkFace : public Face
{
public:
	WinkFace(Point c, int r);
	void draw(AnimationWindow& win) override;
};
