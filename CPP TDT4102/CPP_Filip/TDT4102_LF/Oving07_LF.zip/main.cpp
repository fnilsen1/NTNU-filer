#include "AnimationWindow.h"
#include "std_lib_facilities.h"
#include "Emoji.h"
#include "Animal.h"

// Definer størrelse på vindu og emoji
constexpr int xmax = 1000;
constexpr int ymax = 600;
constexpr int emojiRadius = 50;

// Tegn alle emojier i en vector<unique_ptr<Emoji>> - en vektor som holder referanser
// til Emoji-objekter - i et Window win.
void draw_emojis(std::vector<std::unique_ptr<Emoji>>& emojis, AnimationWindow& win)
{
	for (int i = 0; i < emojis.size(); ++i)
	{
		emojis.at(i)->draw(win);
	}

}

int main()
{
	testAnimal();

	const Point tl{100, 100};
	const string win_label{"Emoji factory"};
	AnimationWindow win{tl.x, tl.y, xmax, ymax, win_label};

	std::vector<std::unique_ptr<Emoji>> es;
	es.emplace_back(new SmilingFace { Point {xmax / 2 - emojiRadius, ymax / 2 - emojiRadius}, emojiRadius});
	es.emplace_back(new SadFace { Point {xmax / 2 + emojiRadius, ymax / 2 - emojiRadius}, emojiRadius});
	es.emplace_back(new SurprisedFace { Point {xmax / 2 - emojiRadius, ymax / 2 + emojiRadius}, emojiRadius});
	es.emplace_back(new AngryFace { Point {xmax / 2 + emojiRadius, ymax / 2 + emojiRadius}, emojiRadius});
	es.emplace_back(new NeutralFace { Point {xmax / 2 + 3 * emojiRadius, ymax / 2 - emojiRadius}, emojiRadius});
	es.emplace_back(new WinkFace { Point {xmax / 2 + 3 * emojiRadius, ymax / 2 + emojiRadius}, emojiRadius});
	draw_emojis(es, win);

	win.wait_for_close();
	return 0;
}
