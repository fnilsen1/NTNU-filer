#include "Animal.h"

string Animal::toString() const {
    return "Animal: " + name + ", " + to_string(age);
}

string Dog::toString() const {
    return "Dog: " + name + ", " + to_string(age);
}

string Cat::toString() const {
    return "Cat: " + name + ", " + to_string(age);
}

void testAnimal() {
    vector<unique_ptr<Animal>> animals;

    animals.emplace_back(new Cat("Tiger", 5));
    animals.emplace_back(new Dog("Fido", 3));
    animals.emplace_back(new Cat("Max", 7));
    animals.emplace_back(new Dog("Buster", 15));
    animals.emplace_back(new Cat("Kitty", 12));
    animals.emplace_back(new Dog("Coco",4));

    for (int i = 0; i < animals.size(); ++i) {
        cout << animals[i]->toString() << '\n';
    }
}
