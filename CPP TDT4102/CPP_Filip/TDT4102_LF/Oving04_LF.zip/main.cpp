
#include "std_lib_facilities.h"
#include "mastermind.h"
#include "masterVisual.h"
#include "tests.h"

int main()
{
	testCallByValue();
	testCallByReference();

	testStudentStruct();
	
	testString();

	//playMastermind(); // Without graphics

	playMastermindVisual();

	return 0;
}
