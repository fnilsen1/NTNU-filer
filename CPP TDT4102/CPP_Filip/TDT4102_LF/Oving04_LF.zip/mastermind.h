#pragma once
#include "std_lib_facilities.h"

void playMastermind();
int checkCharactersAndPosition(string code, string guess);
int checkCharacters(string code, string guess);

bool askYesNoQuestion(string questionMessage);

