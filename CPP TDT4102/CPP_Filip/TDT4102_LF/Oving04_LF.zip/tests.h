#pragma once
#include "utilities.h"

void testCallByValue();
void testCallByReference();
void testStudentStruct();
void testString();
