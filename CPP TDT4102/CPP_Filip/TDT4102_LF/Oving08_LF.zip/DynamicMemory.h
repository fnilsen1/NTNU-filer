#pragma once

void createFibonacci();