#pragma once
#include "std_lib_facilities.h"

void writeUserInputToFile();
void addLineNumbers(const filesystem::path& filename);