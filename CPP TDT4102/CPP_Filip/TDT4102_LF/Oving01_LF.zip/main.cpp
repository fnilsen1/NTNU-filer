//Løsningsforslag Øving 1
// Oversettelse fra Python til C++
#include "std_lib_facilities.h"

int maxOfTwo(int a, int b)  
{
	if (a > b) {
		cout << "A is greater than B\n";
		return a;
	} else {
		cout << "B is greater than or equal to A\n";
		return b;  
	}
}

int fibonacci(int n)
{
	int a = 0;
	int b = 1;
	cout << "Fibonacci numbers:\n";
	for (int x = 1; x <= n; ++x) {
		cout << x << ' ' << b << '\n';
		int temp = b;
		b += a;
		a = temp;
	}
	cout << "----\n";
	return b;
}

int squareNumberSum(int number)
{
	int totalSum = 0;
	for (int index = 1; index <= number; ++index) {
		totalSum += index * index; // pow(index, 2)

		cout << index * index << '\n';
	}
	cout << totalSum << '\n';
	return totalSum;
}

void triangleNumbersBelow(int number)
{
	int acc = 1;
	int num = 2;
	cout << "Triangle numbers below " << number << ":\n";
	while (acc < number) {
		cout << acc << '\n';
		acc += num;
		++num;
	}
	cout << '\n';
}

bool isPrime(int number)
{
	for (int divisor = 2; divisor < number; ++divisor) {
		if (number % divisor == 0) {
			return false;
		}
	}
	return true;
}

void naivePrimeNumberSearch(int maxNumber)
{
	for (int number = 2; number < maxNumber; ++number) {
		if (isPrime(number)) {
			cout << number << " is a prime\n";
		}
	}
}

void inputAndPrintNameAndAge(){
	string name;
	int age;
	cout << "Skriv inn et navn: ";
	cin >> name;
	cout << "Skriv inn alderen til " << name << ": ";
	cin >> age;
	cout << name << " er " << age << " aar gammel." << endl;
}

int main()
{
	cout << "Oppgave a)" << endl;
	cout << maxOfTwo(5, 6) << endl;

	cout << "Oppgave c)" << endl;
	cout << fibonacci(5) << endl;

	cout << "Oppgave d)" << endl;
	cout << squareNumberSum(5) << endl;

	cout << "Oppgave e)" << endl;
	triangleNumbersBelow(10);

	cout << "Oppgave f)\n7 is a prime: " << isPrime(7)
	     << ", 33 is a prime: " << isPrime(33) << endl;

	cout << "Oppgave g)" << endl;
	naivePrimeNumberSearch(14);

	cout << "Oppgave h)" << endl;
	inputAndPrintNameAndAge();

	return 0;
}
