#pragma once
#include "std_lib_facilities.h"
#include "AnimationWindow.h"

// Abstrakt klasse. Arvende konkrete klasser må implementere funksjonen draw()
// som tegner former i vinduet de skal bli vist i.
class Emoji
{
public:
    virtual void draw(AnimationWindow&) = 0;
    virtual ~Emoji(){}; //destruktør
};

struct Point {
    int x, y;
    Point(int _x, int _y) : x(_x), y(_y) {}
};

struct Color {
    int r, g, b;
    Color(int _r, int _g, int _b) : r(_r), g(_g), b(_b) {}
};

void draw_circle(AnimationWindow& win, const Point& centre, int radius, const Color& color);
void draw_arc(AnimationWindow& win, const Point& centre, int width, int height, int start_angle, int end_angle, const Color& color);
void draw_line(AnimationWindow& win, const Point& start, const Point& end, const Color& color);

struct Face {
    Point centre;
    int radius;
    Face(const Point& c, int r) : centre(c), radius(r) {}
};

void draw_face(AnimationWindow& win, const Face& face);
void draw_eye(AnimationWindow& win, const Point& centre, int radius, const Color& color);
void draw_smile(AnimationWindow& win, const Point& centre, int radius, const Color& color);
void draw_frown(AnimationWindow& win, const Point& centre, int radius, const Color& color);
void draw_wink(AnimationWindow& win, const Point& centre, int radius, const Color& color);
void draw_weird_feature(AnimationWindow& win, const Point& centre, int radius, const Color& color);
void draw_expression(AnimationWindow& win, const Face& face, const std::string& expression);

#endif