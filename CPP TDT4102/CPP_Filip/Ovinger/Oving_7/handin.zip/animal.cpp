#include "std_lib_facilities.h"
#include "Animal.h"
#include "Graph.h"
using namespace Graph_lib;

class Animal {
protected:
    std::string name;
    int age;

public:
    Animal(const std::string& name, int age) : name(name), age(age) {}
    virtual std::string toString() const = 0;
};

class Cat : public Animal {
public:
    Cat(const std::string& name, int age) : Animal(name, age) {}
    std::string toString() const override {
        return "Cat: " + name + ", " + std::to_string(age) + "\n";
    }
};

class Dog : public Animal {
public:
    Dog(const std::string& name, int age) : Animal(name, age) {}
    std::string toString() const override {
        return "Dog: " + name + ", " + std::to_string(age) + "\n";
    }
};

void testAnimal() {
    Cat katt{"Morad", 100};
    Dog hund{"Karl", 6};
    Cat katt1{"Jack", 4};
    Dog hund1{"Fredrik", 1};

    std::cout << katt1.toString();
    std::cout << katt.toString();
    std::cout << hund.toString();
    std::cout << hund1.toString();

    std::vector<std::unique_ptr<Animal>> v;
    v.emplace_back(std::make_unique<Cat>("A", 8));
    v.emplace_back(std::make_unique<Dog>("B", 8));
    v.emplace_back(std::make_unique<Dog>("C", 8));
    v.emplace_back(std::make_unique<Cat>("D", 8));

    for(const auto& animal : v) {
        std::cout << animal->toString();
    } 
}

int main() {
    testAnimal();
    return 0;
}
