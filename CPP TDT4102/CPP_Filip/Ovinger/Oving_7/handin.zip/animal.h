#pragma once
#include "std_lib_facilities.h"
#include "Graph.h"
using namespace Graph_lib;

template<typename T>
class Animal {
protected:
    std::string name;
    int age;

public:
    Animal(const std::string& name, int age) : name(name), age(age) {}
    virtual ~Animal() {}

    virtual std::string toString() const = 0;
};


class Cat : public Animal<Cat> {
public:
    Cat(const std::string& name, int age) : Animal(name, age) {}
    std::string toString() const override {
        return "Cat: " + name + ", Age: " + std::to_string(age);
    }
};


class Dog : public Animal<Dog> {
public:
    Dog(const std::string& name, int age) : Animal(name, age) {}
    std::string toString() const override {
        return "Dog: " + name + ", Age: " + std::to_string(age);
    }
};


void testAnimal() {
    Cat cat("Fluffy", 5);
    Dog dog("Buddy", 3);

    std::cout << cat.toString() << std::endl;
    std::cout << dog.toString() << std::endl;
}

int main() {
    testAnimal();
    return 0;
}
