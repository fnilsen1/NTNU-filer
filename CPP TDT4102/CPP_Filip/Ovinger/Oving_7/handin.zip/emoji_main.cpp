#include "AnimationWindow.h"
#include "Emoji.h"
#include "Animal.h"
#include <vector>

// Definer størrelse på vindu og emoji
constexpr int xmax = 1000;
constexpr int ymax = 600;
constexpr int emojiRadius = 50;


int main()
{
    const Point tl{100, 100};
    const string win_label{"Emoji factory"};
    AnimationWindow win{tl.x, tl.y, xmax, ymax, win_label};

    std::vector<Point> positions = {tl, {tl.x + 150, tl.y}, {tl.x + 300, tl.y}, {tl.x + 450, tl.y}, {tl.x + 600, tl.y}};
    std::vector<Face*> faces;
    faces.push_back(new EmptyFace{positions[0], emojiRadius});
    faces.push_back(new SmilyFace{positions[1], emojiRadius});
    faces.push_back(new SadFace{positions[2], emojiRadius});
    faces.push_back(new WinkyFace{positions[3], emojiRadius});
    faces.push_back(new WeirdFace{positions[4], emojiRadius});

    for (auto face : faces) {
        face->draw(win);
    }

    win.wait_for_close();

    for (auto face : faces) {
        delete face;
    }
}
