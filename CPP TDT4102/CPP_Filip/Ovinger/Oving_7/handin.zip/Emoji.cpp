#include "Emoji.h"
#include "AnimationWindow.h"


struct Point {
    int x, y;
    Point(int _x, int _y) : x(_x), y(_y) {}
};


struct Color {
    int r, g, b;
    Color(int _r, int _g, int _b) : r(_r), g(_g), b(_b) {}
};

void draw_circle(AnimationWindow& win, const Point& centre, int radius, const Color& color) {
    std::cout << "Drawing circle at (" << centre.x << ", " << centre.y << ") with radius " << radius << " and color (" << color.r << ", " << color.g << ", " << color.b << ")\n";
}

void draw_arc(AnimationWindow& win, const Point& centre, int width, int height, int start_angle, int end_angle, const Color& color) {
    std::cout << "Drawing arc at (" << centre.x << ", " << centre.y << ") with width " << width << ", height " << height << ", start angle " << start_angle << ", end angle " << end_angle << " and color (" << color.r << ", " << color.g << ", " << color.b << ")\n";
}

void draw_line(AnimationWindow& win, const Point& start, const Point& end, const Color& color) {
    std::cout << "Drawing line from (" << start.x << ", " << start.y << ") to (" << end.x << ", " << end.y << ") with color (" << color.r << ", " << color.g << ", " << color.b << ")\n";
}

struct Face {
    Point centre;
    int radius;
    Face(const Point& c, int r) : centre(c), radius(r) {}
};

void draw_face(AnimationWindow& win, const Face& face) {
    draw_circle(win, face.centre, face.radius, Color(255, 255, 0));
    draw_arc(win, face.centre, 2 * face.radius, 2 * face.radius, 0, 360, Color(0, 0, 0));
}

void draw_eye(AnimationWindow& win, const Point& centre, int radius, const Color& color) {
    draw_circle(win, centre, radius, color);
}

void draw_smile(AnimationWindow& win, const Point& centre, int radius, const Color& color) {
    draw_arc(win, centre, radius, radius * 2 / 3, 240, 300, color);
}

void draw_frown(AnimationWindow& win, const Point& centre, int radius, const Color& color) {
    draw_arc(win, Point(centre.x, centre.y + radius), radius, radius * 2 / 3, 60, 120, color);
}

void draw_wink(AnimationWindow& win, const Point& centre, int radius, const Color& color) {
    draw_eye(win, Point(centre.x - radius / 4, centre.y - radius / 10), radius / 10, Color(255, 0, 0)); 
    draw_arc(win, Point(centre.x + radius / 4, centre.y + radius / 10), radius / 5, radius / 5, 50, 130, color);
    draw_smile(win, centre, radius, color);
}

void draw_weird_feature(AnimationWindow& win, const Point& centre, int radius, const Color& color) {
    draw_arc(win, Point(centre.x - radius / 4, centre.y - radius / 9), radius / 6, radius / 6, 45, 100, color);
    draw_line(win, Point(centre.x + radius / 4, centre.y - radius / 3), Point(centre.x, centre.y - radius / 7), color);
    draw_circle(win, Point(centre.x, centre.y + radius / 2), radius / 3, color);
}

void draw_expression(AnimationWindow& win, const Face& face, const std::string& expression) {
    if (expression == "smile") {
        draw_face(win, face);
        draw_smile(win, face.centre, face.radius, Color(0, 0, 0)); 
    } else if (expression == "frown") {
        draw_face(win, face);
        draw_frown(win, face.centre, face.radius, Color(0, 0, 0)); 
    } else if (expression == "wink") {
        draw_face(win, face);
        draw_wink(win, face.centre, face.radius, Color(0, 0, 0)); 
    } else if (expression == "weird") {
        draw_face(win, face);
        draw_weird_feature(win, face.centre, face.radius, Color(0, 0, 0)); 
    } else {
        std::cout << "Unknown expression\n";
    }
}
