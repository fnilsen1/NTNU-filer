#include <iostream>
#include "Tetromino.h"
#include "TetrisWindow.h"



int main()
{


/********************************************************/
//Opprett vindu her
TetrisWindow TetrisWindow;
/********************************************************/
//kall run på det her
TetrisWindow.run();

	return 0;
}
