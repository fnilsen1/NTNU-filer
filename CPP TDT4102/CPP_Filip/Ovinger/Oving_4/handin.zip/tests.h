#pragma once

void testCallByValue();
void testCallByReference();