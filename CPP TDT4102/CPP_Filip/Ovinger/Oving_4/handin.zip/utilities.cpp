#include "std_lib_facilities.h"

int incrementByValueNumTimes(int startValue, int increment, int numTimes) {
for (int i = 0; i < numTimes; i++) {
startValue += increment;
}
return startValue;
}

int incrementByValueNumTimesRef(int& startValue, int& increment, int& numTimes) {
for (int i = 0; i < numTimes; i++) {
startValue += increment;
}
return startValue;
}

//Bør bruke referanser fordi vi skal endre på variabler utenfor funksjonen. 
void swapNumbers(int& a, int& b){
    int tmp = a;
    a = b;
    b = tmp;
}

#include <iostream>

int main() {
    char operasjon;
    double tall1, tall2, resultat;

    std::cout << "Velkommen til kalkulatoren!" << std::endl;
    std::cout << "Vennligst skriv inn et regnestykke (for eksempel 5 + 3): ";
    std::cin >> tall1 >> operasjon >> tall2;

    switch (operasjon) {
        case '+':
            resultat = tall1 + tall2;
            std::cout << "Resultatet av " << tall1 << " + " << tall2 << " er " << resultat << std::endl;
            break;
        case '-':
            resultat = tall1 - tall2;
            std::cout << "Resultatet av " << tall1 << " - " << tall2 << " er " << resultat << std::endl;
            break;
        case '*':
            resultat = tall1 * tall2;
            std::cout << "Resultatet av " << tall1 << " * " << tall2 << " er " << resultat << std::endl;
            break;
        case '/':
            if (tall2 != 0) {
                resultat = tall1 / tall2;
                std::cout << "Resultatet av " << tall1 << " / " << tall2 << " er " << resultat << std::endl;
            } else {
                std::cout << "Feil: Kan ikke dele på null!" << std::endl;
            }
            break;
        default:
            std::cout << "Ugyldig operasjon!" << std::endl;
            break;
    }

    return 0;
}