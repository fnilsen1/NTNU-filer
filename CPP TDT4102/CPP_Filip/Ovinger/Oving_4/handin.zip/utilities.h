#pragma once

int incrementByValueNumTimes(int startValue, int increment, int numTimes);
int incrementByValueNumTimesRef(int& startValue, int& increment, int& numTimes);
void swapNumbers(int& a, int& b);