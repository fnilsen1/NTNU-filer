#include "std_lib_facilities.h"
#include "utilities.h"
#include "tests.h"

int main() {
    testCallByValue();
    testCallByReference();
    int a = 3;
    int b = 10;
    swapNumbers(a, b);
    return 0;
}

double beregnGjennomsnitt(const std::vector<int>& tall) {
    int sum = 0;
    for (int t : tall) {
        sum += t;
    }
    return static_cast<double>(sum) / tall.size();
}

int main() {
    std::vector<int> tall = {10, 20, 30, 40, 50};

    std::cout << "Tallene i listen er:";
    for (int t : tall) {
        std::cout << " " << t;
    }
    std::cout << std::endl;

    double gjennomsnitt = beregnGjennomsnitt(tall);
    std::cout << "Gjennomsnittet av tallene er: " << gjennomsnitt << std::endl;

    return 0;
}

#include <iostream>

int main() {
    char operasjon;
    double tall1, tall2, resultat;

    std::cout << "Velkommen til kalkulatoren!" << std::endl;
    std::cout << "Vennligst skriv inn et regnestykke (for eksempel 5 + 3): ";
    std::cin >> tall1 >> operasjon >> tall2;

    switch (operasjon) {
        case '+':
            resultat = tall1 + tall2;
            std::cout << "Resultatet av " << tall1 << " + " << tall2 << " er " << resultat << std::endl;
            break;
        case '-':
            resultat = tall1 - tall2;
            std::cout << "Resultatet av " << tall1 << " - " << tall2 << " er " << resultat << std::endl;
            break;
        case '*':
            resultat = tall1 * tall2;
            std::cout << "Resultatet av " << tall1 << " * " << tall2 << " er " << resultat << std::endl;
            break;
        case '/':
            if (tall2 != 0) {
                resultat = tall1 / tall2;
                std::cout << "Resultatet av " << tall1 << " / " << tall2 << " er " << resultat << std::endl;
            } else {
                std::cout << "Feil: Kan ikke dele på null!" << std::endl;
            }
            break;
        default:
            std::cout << "Ugyldig operasjon!" << std::endl;
            break;
    }

    return 0;
}