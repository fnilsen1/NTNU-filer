from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path

from graphslam.config import SlamConfig
from graphslam.loaders.victoria_park import VictoriaParkLoader
from graphslam.slam import run_slam


def run_real(
    config: SlamConfig,
    output_dir: Path,
    num_steps: int | None,
    show_plots: bool = False,
    save_plots: bool = True,
    save_on_abort: bool = True,
) -> None:
    dataset = VictoriaParkLoader(initial_heading_deg=config.victoria_park.initial_heading_deg)
    return run_slam(
        config=config,
        dataset=dataset,
        output_dir=output_dir,
        num_steps=num_steps,
        show_plots=show_plots,
        save_plots=save_plots,
        save_on_abort=save_on_abort,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run factor graph SLAM on the Victoria Park data set.")
    parser.add_argument("--config", type=Path, default=Path("configs/real_default.yaml"))
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--steps", type=int, default=7300)
    parser.add_argument("--no-show-plots", action="store_true", help="Do not display plots after the run.")
    parser.add_argument("--no-save-plots", action="store_true", help="Do not save plots to the run directory.")
    parser.add_argument(
        "--no-save-on-abort",
        action="store_true",
        help="On Ctrl+C, exit without saving. By default an interrupted run is saved up to the last completed step.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir
    if output_dir is None:
        output_dir = Path("runs/real") / datetime.now().strftime("%Y%m%d_%H%M%S")

    config = SlamConfig.load(args.config)

    run_real(
        config=config,
        output_dir=output_dir,
        num_steps=args.steps,
        show_plots=not args.no_show_plots,
        save_plots=not args.no_save_plots,
        save_on_abort=not args.no_save_on_abort,
    )


if __name__ == "__main__":
    main()
