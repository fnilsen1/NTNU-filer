from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy.io import loadmat

from graphslam.config import SlamConfig
from graphslam.paths import victoria_park_folder
from graphslam.preprocessing import extract_tree_measurements, preintegrate, relative_pose
from graphslam.slam import SlamStepInput


@dataclass(slots=True)
class WheelOdometry:
    velocity: float
    steering: float
    dt: float


@dataclass(slots=True)
class RawLidarStepInput:
    odometry: list[WheelOdometry]
    scan: np.ndarray
    scan_time: float
    scan_step: int


class VictoriaParkLoader:
    name = "victoria_park"

    def __init__(self, data_folder: Path | None = None, initial_heading_deg: float = 36.0):
        self.initial_heading_deg = initial_heading_deg
        if data_folder is None:
            data_folder = victoria_park_folder()

        self._load_data(data_folder)
        self._prepare_odometry_intervals()

    def _load_data(self, data_folder: Path):
        raw_data = {
            **loadmat(str(data_folder / "aa3_dr")),
            **loadmat(str(data_folder / "aa3_lsr2")),
            **loadmat(str(data_folder / "aa3_gpsx")),
        }

        # Laser scans: cm -> m, ms -> s
        self.lsr_scans = raw_data["LASER"] / 100.0
        self.lsr_timestamps = raw_data["TLsr"].ravel() / 1000.0

        # Wheel odometry: ms -> s
        self.odo_steering = raw_data["steering"].ravel()
        self.odo_velocity = raw_data["speed"].ravel()
        self.odo_timestamps = raw_data["time"].ravel() / 1000.0

        # gnss: ms -> s
        self.gnss_latitude = raw_data["La_m"].ravel()
        self.gnss_longitude = raw_data["Lo_m"].ravel()
        self.gnss_timestamps = raw_data["timeGps"].ravel() / 1000.0

    def _prepare_odometry_intervals(self):
        """Odometry intervals: ``(velocity[k], steering[k])`` applies over
        ``[odo_timestamps[k], odo_timestamps[k + 1]]``.
        """
        self.odo_interval_t0 = self.odo_timestamps[:-1]
        self.odo_interval_t1 = self.odo_timestamps[1:]

        self.odo_interval_velocity = self.odo_velocity[:-1]
        self.odo_interval_steering = self.odo_steering[:-1]

        if np.any(self.odo_interval_t1 <= self.odo_interval_t0):
            raise ValueError("Odometry timestamps must be strictly increasing.")

    def _odometry_between(self, t0: float, t1: float) -> list[WheelOdometry]:
        """Odometry inputs clipped to ``[t0, t1]``, each with its clipped ``dt``."""
        if t1 <= t0:
            return []

        # Find odometry intervals that overlap [t0, t1].
        first = np.searchsorted(self.odo_interval_t1, t0, side="right")
        last = np.searchsorted(self.odo_interval_t0, t1, side="left")

        if first >= last:
            return []

        # Clip intervals to [t0, t1] and compute dt for each interval.
        starts = np.maximum(self.odo_interval_t0[first:last], t0)
        ends = np.minimum(self.odo_interval_t1[first:last], t1)
        dts = ends - starts

        return [
            WheelOdometry(
                velocity=float(v),
                steering=float(a),
                dt=float(dt),
            )
            for v, a, dt in zip(
                self.odo_interval_velocity[first:last],
                self.odo_interval_steering[first:last],
                dts,
            )
        ]

    def iterate(self, max_steps: int | None = None) -> Iterator[RawLidarStepInput]:
        """
        Iterate over LiDAR-to-LiDAR steps.
        """
        start_lidar_idx = 2 # as first lidar measurement (idx 0) is before odometry starts
        stop_lidar_idx = self.lsr_timestamps.size
        scan_step = 0

        if max_steps is not None:
            stop_lidar_idx = min(stop_lidar_idx, start_lidar_idx + max_steps)

        for lidar_idx in range(start_lidar_idx, stop_lidar_idx):
            if scan_step == 0:
                # The first scan sits at the prior pose X(0); the car is still standing.
                odometry: list[WheelOdometry] = []
            else:
                t0 = float(self.lsr_timestamps[lidar_idx - 1])
                t1 = float(self.lsr_timestamps[lidar_idx])
                odometry = self._odometry_between(t0, t1)

            yield RawLidarStepInput(
                odometry=odometry,
                scan=self.lsr_scans[lidar_idx],
                scan_time=self.lsr_timestamps[lidar_idx],
                scan_step=scan_step,
            )
            scan_step += 1


    def iterate_slam(
        self,
        config: SlamConfig,
        max_steps: int | None = None,
    ) -> Iterator[SlamStepInput]:
        for meas in self.iterate(max_steps):
            if not meas.odometry:
                # First scan: no motion into the prior pose X(0).
                delta_T, delta_cov = None, None
            else:
                delta_odo = []
                delta_odo_covs = []

                for odo in meas.odometry:
                    delta_odo.append(relative_pose(odo.velocity, odo.steering, odo.dt))
                    delta_odo_covs.append(config.noise.odom_cov_matrix * odo.dt)

                delta_T, delta_cov = preintegrate(delta_odo, delta_odo_covs)

            yield SlamStepInput(
                relative_pose=delta_T,
                relative_pose_cov=delta_cov,
                measurements=extract_tree_measurements(meas.scan, config.sensor.max_range),
                scan_time=float(meas.scan_time),
            )

    @property
    def max_steps(self) -> int:
        return max(0, self.lsr_timestamps.size - 2)

    @property
    def lidar(self) -> np.ndarray:
        return np.column_stack(
            [self.lsr_timestamps, self.lsr_scans]
        )

    @property
    def odometry(self) -> np.ndarray:
        return np.column_stack(
            [self.odo_timestamps, self.odo_velocity, self.odo_steering]
        )

    @property
    def gnss(self) -> np.ndarray:
        return np.column_stack(
            [self.gnss_timestamps, self.gnss_longitude, self.gnss_latitude]
        )

    @property
    def gnss_filtered(self) -> np.ndarray:
        gnss = self.gnss
        return np.delete(gnss, find_gnss_outliers(gnss), axis=0)

    @property
    def initial_pose(self) -> np.ndarray:
        """First GNSS fix for the position; heading from ``victoria_park.initial_heading_deg``."""
        return np.array(
            [self.gnss_longitude[0], self.gnss_latitude[0], np.deg2rad(self.initial_heading_deg)]
        )
    

GNSS_MAX_SPEED_M_S = 1
GNSS_OUTLIER_MARGIN_M = 1.0

# Helper function to identify large outliers in GNSS data based on speed and distance criteria.
def find_gnss_outliers(
    gnss: np.ndarray,
    max_speed_m_s: float = GNSS_MAX_SPEED_M_S,
    distance_margin_m: float = GNSS_OUTLIER_MARGIN_M,
) -> np.ndarray:
    """Indices of isolated GNSS samples too far from both neighbours to be
    reachable at ``max_speed_m_s``.
    """
    times = gnss[:, 0]
    positions = gnss[:, 1:3]

    dt_prev = times[1:-1] - times[:-2]
    dt_next = times[2:] - times[1:-1]

    dist_prev = np.linalg.norm(positions[1:-1] - positions[:-2], axis=1)
    dist_next = np.linalg.norm(positions[2:] - positions[1:-1], axis=1)

    too_far_from_prev = dist_prev > max_speed_m_s * dt_prev + distance_margin_m
    too_far_from_next = dist_next > max_speed_m_s * dt_next + distance_margin_m
    
    outlier_mask = ~np.isfinite(times) | ~np.all(np.isfinite(positions), axis=1)
    outlier_mask[1:-1] |= (too_far_from_prev & too_far_from_next)

    return np.flatnonzero(outlier_mask)



    
    
   
